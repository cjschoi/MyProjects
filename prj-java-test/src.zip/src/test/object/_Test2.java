package test.object;


public class _Test2  {
	public static void main(String[] args){
 
    }
}

